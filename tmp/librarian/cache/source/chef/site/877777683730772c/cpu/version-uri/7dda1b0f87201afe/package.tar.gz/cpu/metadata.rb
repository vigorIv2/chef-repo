name             "cpu"
maintainer       "Guilhem Lettron"
maintainer_email "guilhem.lettron@youscribe.com"
license          "Apache v2.0"
description      "Manage CPU Governor on linux"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.2.0"
supports         "ubuntu"
supports         "debian"
